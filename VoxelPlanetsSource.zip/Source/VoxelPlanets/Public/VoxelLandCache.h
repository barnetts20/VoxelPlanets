// VoxelLandCache.h - The land surface cache (Design/LandSurfaceCache.md): the terrestrial
// surface's height, gradient and fields around the camera, as a clipmap of levels written by
// compute (Shaders/Private/VoxelLandCacheWrite.usf) and sampled by the terrain material's land
// node (VoxelLandCacheSample.ush). Geometry: Shaders/Private/VoxelLandCache.ush.
//
// The terrain actor owns one per terrestrial density: the textures (render targets, kept alive
// by the actor's properties) and the plan (Private/VoxelLandCachePlan.h: the levels' anchors and
// windows, and what to write each frame within a texel budget, voxel.Land.CacheTexelsPerFrame).
//
// The terrain edits are in it (Design/EditsAndCaves.md, E2; VoxelLandCacheEdits.ush): the writes
// apply the brick terrain's GPU edit data (SetEdits), and an edit's texels are written again
// (NotifyEdit) once that data carries it, so the cache and the mesh change together.

#pragma once

#include "CoreMinimal.h"
#include <atomic>

class FVoxelTerrestrialDensity;
struct FVoxelDensityGPUData;
struct FVoxelEditGPUData;
class UMaterialInstanceDynamic;
class UTextureRenderTarget2D;
class UTexture2DDynamic;
namespace VoxelLandCachePlan { class FPlan; struct FJob; }

/** The cache's textures (VoxelLandCache.ush lists their contents). */
struct FVoxelLandCacheTextures
{
    UTextureRenderTarget2D* Height = nullptr;   // R32F atlas
    UTextureRenderTarget2D* Slope = nullptr;    // RGBA16F atlas
    UTextureRenderTarget2D* Fields = nullptr;   // RGBA16F atlas
    UTexture2DDynamic* State = nullptr;         // RGBA32F, VOXEL_LAND_CACHE_STATE_WIDTH x (levels + 1)

    bool IsValid() const { return Height && Slope && Fields && State; }
};

class VOXELPLANETS_API FVoxelLandCache
{
public:
    /** The material's parameter names (Texture Objects; STAGE_C1_NOTES.md). */
    static const FName HeightTextureName;   // VoxelLandCacheHeight
    static const FName SlopeTextureName;    // VoxelLandCacheSlope
    static const FName FieldsTextureName;   // VoxelLandCacheFields
    static const FName StateTextureName;    // VoxelLandCacheState

    /** Levels for a sea-level radius (cm): the coarsest reaches R tan 70 degrees along the plane
     *  (60 degrees of arc about the camera once a level is 10 degrees off it), at least 1, at
     *  most VOXEL_LAND_CACHE_MAX_LEVELS (22: radii to about 49,000 km). */
    static int32 LevelsFor(double SeaRadius);

    /** Tiles the atlases need for Levels levels: one each, and the spare a re-centring level is
     *  written into. */
    static int32 TilesFor(int32 Levels);

    /** Game thread. The textures for Levels levels (transient objects in Outer); false when the
     *  RHI can't create them. */
    static bool MakeTextures(int32 Levels, UObject* Outer, FVoxelLandCacheTextures& Out);

    FVoxelLandCache();
    ~FVoxelLandCache();
    FVoxelLandCache(const FVoxelLandCache&) = delete;
    FVoxelLandCache& operator=(const FVoxelLandCache&) = delete;

    /** Game thread. Starts the cache for a terrestrial density's land (empty: every level is
     *  written as the camera is first seen). False when the textures can't hold its levels. */
    bool Initialize(const FVoxelTerrestrialDensity& Density, const FVoxelLandCacheTextures& InTextures);
    void Reset();
    /** Initialized: the state the material reads is uploaded (no level valid until written). */
    bool IsInitialized() const { return GPUData.IsValid(); }
    /** Initialized, and the writes can run (the write shader compiled, the textures' resources):
     *  without, the material is told to evaluate the land itself. */
    bool IsWritable() const;
    /** Why it isn't writable (empty when it is): for the log, so the material's fallback to the
     *  analytic node is never silent. */
    FString WhyNotWritable() const;
    int32 GetLevels() const;
    double GetSeaRadius() const { return SeaRadius; }

    /** Game thread, every frame (a second call in a frame does nothing): the primary camera in
     *  the planet's frame (cm, no scale). Moves the levels' windows, re-anchors levels the camera
     *  has left, and writes what that exposes, within the budget; the state the material reads
     *  follows what is written. Waits while the write shader or the textures aren't ready. */
    void Tick(const FVector& CameraPlanet);

    /** Game thread, every frame before Tick: the terrain edits the writes apply (the brick
     *  terrain's GPU data, built at Sequence; null: not built yet, the last set stays). A notice
     *  at or before Sequence then writes its texels again. A sequence going back (the edit
     *  store replaced) writes everything again. */
    void SetEdits(TSharedPtr<const FVoxelEditGPUData> InEdits, uint32 Sequence);

    /** Game thread. Edit Sequence changed the density within Bounds (the planet's frame, cm):
     *  its texels are written again, in place and ahead of the other writes, once the edits set
     *  carry it (SetEdits). */
    void NotifyEdit(uint32 Sequence, const FBox& Bounds);

    /** Game thread. The textures on a material instance. */
    void SetTextureParameters(UMaterialInstanceDynamic* Material) const;

    /** The levels' windows as texels written, valid and pending (voxel.Debug.LandCache). */
    FString Describe() const;

    /** Game thread (stage O9m: the ocean's depths read the cache). The textures (valid once
     *  initialized). */
    const FVoxelLandCacheTextures& GetTextures() const { return Textures; }
    /** The newest edit sequence whose texels the writes enqueued so far all carry: every edit
     *  at or before it is in what a render command enqueued from the next frame on reads. */
    uint32 GetSettledEditSequence() const { return SettledEditSequence; }
    /** The cache is being written for the camera: its writes ran in one of the last two frames
     *  (an unticked cache's windows stay where they were, and its edits never settle). */
    bool IsLive() const;

private:
    /** Enqueues the jobs (the plan's, this frame) and the state after them; false when the
     *  textures have no resources. */
    bool Dispatch(const VoxelLandCachePlan::FJob* Jobs, int32 NumJobs);

    TUniquePtr<VoxelLandCachePlan::FPlan> Plan;
    TSharedPtr<const FVoxelDensityGPUData, ESPMode::ThreadSafe> GPUData;
    /** The edits the writes apply, and the edit sequence they were built at. */
    TSharedPtr<const FVoxelEditGPUData> Edits;
    uint32 EditsSequence = 0;
    /** Notices the edits set doesn't carry yet. */
    struct FPendingEdit
    {
        uint32 Sequence = 0;
        FBox Bounds = FBox(ForceInit);
    };
    TArray<FPendingEdit> PendingEdits;
    double SeaRadius = 0.0;
    FVoxelLandCacheTextures Textures;
    uint64 TexelsWritten = 0;
    uint64 LastTickFrame = MAX_uint64;
    /** The state last uploaded (Dispatch), and the generation then: an unchanged one with no job
     *  isn't uploaded again. */
    TArray<FVector4f> StateUploaded;
    uint32 StateUploadedGeneration = MAX_uint32;
    /** The last frame whose writes were enqueued (IsLive), and GetSettledEditSequence's. */
    uint64 LastLiveFrame = 0;
    uint32 SettledEditSequence = 0;
    /** Notices whose texels are in the plan's dirty rectangles, not yet all written. */
    TArray<FPendingEdit> Unsettled;
    /** A frame's writes that couldn't run on the render thread (the plan had moved on): the
     *  render thread raises FailedGeneration past the generation the frame was planned in; the
     *  game thread then writes every level again (a new generation), and until it has, every
     *  state uploaded shows no level valid (frames planned before it noticed). */
    uint32 Generation = 0;
    TSharedPtr<std::atomic<uint32>, ESPMode::ThreadSafe> FailedGeneration;
    /** Whether the last upload's levels were zeroed by the render thread (the writes couldn't
     *  run): the state is uploaded again then, even unchanged (MAT-1's skip). */
    TSharedPtr<std::atomic<bool>, ESPMode::ThreadSafe> UploadZeroed;
};
