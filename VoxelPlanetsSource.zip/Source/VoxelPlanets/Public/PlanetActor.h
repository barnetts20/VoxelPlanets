// PlanetActor.h - Top-level planet actor that orchestrates terrain, ocean, and
// gravity child actors. Owns the shared density compositor (noise + edit store)
// that both terrain and ocean subsystems sample from.
//
// Actor scale determines planet radius (max component, in cm). Child actors
// inherit position and rotation from PlanetRoot but use absolute scale
// (set explicitly per-child based on their respective radii).
//
// Initialization is deferred to Tick via bPendingInitialize to avoid spawning
// child actors during OnConstruction (which is unsafe in UE5).

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "PlanetTerrainActor.h"
#include "VoxelTerrainOwner.h"
#include "OceanSphereActor.h"
#include "FDensitySampleCompositor.h"
#include "VoxelDensity.h"
#include "VoxelLandSettings.h"
#include "VoxelOceanSettings.h"
#include "VoxelLandClimate.h"
#include "PooledActor.h"
#include "SeededAtmosphereActor.h"
#include "PlanetActor.generated.h"

class APlanetGravityZone;
class FVoxelLandBaker;
struct FVoxelLandBake;
class UVoxelOceanProfile;
struct FVoxelLandNoiseSet;
struct FVoxelLandClimateField;
class UTexture2DDynamic;

/** Stage T5b: where the planet's climate capture stands (APlanetActor::UpdateClimateCapture). */
enum class EVoxelPlanetClimateCapture : uint8
{
    None,       // nothing captured for the current bake and atmosphere
    Waiting,    // the atmosphere spins up for its snapshot
    Captured,   // the snapshot (or the provisional model) is kept for this seed
};

/** Stage A11: the climate at a point (APlanetActor::GetClimateAt), from the atmosphere's sim
 *  (its long-run means) and the planet's own latitude and ground. */
USTRUCT(BlueprintType)
struct VOXELPLANETS_API FVoxelPlanetClimate
{
    GENERATED_BODY()

    /** Mean temperature (degrees C): the latitude's profile, the sim's warmth, the ground's
     *  height through the lapse rate. */
    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float Temperature = 0.0f;

    /** Precipitation (the sim's long-run net condensation: about 0 dry, 0.05 to 0.3 wet). */
    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float Precipitation = 0.0f;

    /** The low air's relative humidity (0 to 1). */
    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float Humidity = 0.0f;

    /** Cloud cover (0 to 1). */
    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float CloudCover = 0.0f;

    /** The ground's height above sea level (m; 0 at sea and on the noise surface). */
    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float Elevation = 0.0f;

    /** False until the atmosphere's sim has given a climate (the temperature is then the
     *  latitude's and the ground's alone). */
    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    bool bFromSim = false;

    /** Stage T5a: true when the land's climate (APlanetActor::LandClimate) gave the values below,
     *  and the temperature (then the terrain material's own, breakup included). */
    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    bool bFromLandClimate = false;

    /** Stage T5a: the summer's mean temperature (degrees C). */
    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float SummerTemperature = 0.0f;

    /** Stage T5a: the precipitation in mm a year (the land climate's calibration of the sim's, or
     *  its provisional model's). */
    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float PrecipitationMm = 0.0f;

    /** Stage T5a: the aridity, log2 of Holdridge's PET ratio (below 0 humid, 1 semi-arid, 2 arid,
     *  3 per-arid). */
    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float Aridity = 0.0f;

    /** Stage T5a: the cover the terrain material shows there (0 to 1 each): snow lying in the
     *  season, glacier ice, bare desert, plant cover. */
    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float Snow = 0.0f;

    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float Glacier = 0.0f;

    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float Desert = 0.0f;

    UPROPERTY(BlueprintReadOnly, Category = "Planet|Climate")
    float Vegetation = 0.0f;
};

/** Top-level planet actor that spawns and coordinates terrain, ocean, atmosphere and
 *  gravity child actors. Stage A1: the atmosphere (CloudAtmosphere's seeded actor) is a child
 *  again, generated from the planet's seed, aimed at the star the star system pushes, and the
 *  ocean's sun.
 *
 *  Builds a shared FDensitySampleCompositor (noise heightmap + sparse edit store)
 *  that is passed to both the terrain and ocean actors so they sample identical
 *  density and share edit state. Scale determines planet radius; child actors
 *  are scaled independently (terrain = PlanetRadius, ocean = OceanRadius,
 *  gravity = max of the two).
 *
 *  The surface comes from one of two generators (Generator): the noise surface
 *  (SurfaceSettings), or the terrestrial generator (TerrestrialSettings), whose bake is made
 *  before the planet is built (time-sliced, cached on disk): until it is ready the planet
 *  keeps what it showed. A terrestrial planet's radius is its sea level.
 *
 *  Property changes are handled via two deferred flags:
 *    - bPendingInitialize: full rebuild (scale, NAR, generator or surface settings changes)
 *    - bPendingOceanUpdate: ocean/gravity toggle or sea level change only
 *  Both go through ConfigureOcean / ConfigureGravity, as the first initialization does.
 *  The ocean's own settings (OceanSettings) and material apply in place, without either. */
UCLASS()
class VOXELPLANETS_API APlanetActor : public AActor, public IPooledActor, public IStarLit, public IVoxelTerrainOwner
{
    GENERATED_BODY()

public:
    APlanetActor();

    /** Root component -- provides the transform gizmo in the editor. */
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Planet")
    TObjectPtr<USceneComponent> PlanetRoot;

    // --- Shape ---

    /** Which generator shapes the surface (a change rebuilds the planet). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Shape")
    EVoxelSurfaceGenerator Generator = EVoxelSurfaceGenerator::Noise;

    /** Noise surface: ratio of noise amplitude to planet radius, shared with child actors.
     *  Terrestrial: the ceiling on the height range (the bake sets the range itself). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Shape", meta = (ClampMin = "0.01", ClampMax = "1.0"))
    double NoiseAmplitudeRatio = 0.15;

    /** Shape of the noise surface's heightfield, shared by terrain and ocean. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Shape",
        meta = (EditCondition = "Generator == EVoxelSurfaceGenerator::Noise", EditConditionHides))
    FVoxelSurfaceSettings SurfaceSettings;

    /** The terrestrial generator: plates, landforms and the bake. Heights are metres about sea
     *  level, which is the planet's radius (the actor scale). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Shape",
        meta = (EditCondition = "Generator == EVoxelSurfaceGenerator::Terrestrial", EditConditionHides))
    FVoxelTerrestrialSettings TerrestrialSettings;

    /** Noise surface: sea level as a fraction of the noise distribution [0, 1].
     *  OceanRadius = PlanetRadius + SeaLevel * NoiseAmplitude (at least 1 cm). A terrestrial
     *  planet's sea level is its radius. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Shape",
        meta = (ClampMin = "-1", ClampMax = "2.0", EditCondition = "Generator == EVoxelSurfaceGenerator::Noise"))
    double SeaLevel = 0.5;

    // --- Ocean ---

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Ocean")
    bool bEnableOcean = true;

    /** The ocean's surface material (empty: the plugin's MT_Ocean). Applies without a rebuild. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Ocean")
    UMaterialInterface* OceanMaterial = nullptr;

    /** The ocean's settings: mesh, land cull, underwater view, optics and environment. The
     *  planet forwards them whole to its ocean (SetOceanSettings), so they survive a respawn;
     *  only what changed is applied (the mesh rebuilds, the rest applies in place). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, BlueprintSetter = SetOceanSettings, Category = "Planet|Ocean")
    FVoxelOceanSettings OceanSettings;

    // --- Ocean seeding (stage A12: VoxelOceanProfile.h) ---

    /** What the ocean's seed draws onto OceanSettings (the base, kept as authored): the water's
     *  and the foam's colours, the waves, the wind... None: the ocean is OceanSettings as they are. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Ocean|Seeding")
    TObjectPtr<UVoxelOceanProfile> OceanProfile = nullptr;

    /** The ocean's seed; -1: the terrain's (TerrestrialSettings.Seed), as the atmosphere's. A
     *  change applies in place. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Ocean|Seeding")
    int32 OceanSeed = -1;

    /** Paths the seed leaves as OceanSettings has them (the profile's paths: WaterColor,
     *  WaveEqualizer.Gain2m...). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Ocean|Seeding")
    TArray<FString> OceanLocks;

    /** A draw's path (or a palette's name: Water, Foam) to hold at OceanSweepPosition in its range
     *  while every other keeps the seed's draw: for finding a range's ends. Not saved. */
    UPROPERTY(EditAnywhere, Transient, Category = "Planet|Ocean|Seeding")
    FString OceanSweepPath;

    UPROPERTY(EditAnywhere, Transient, Category = "Planet|Ocean|Seeding", meta = (ClampMin = "0.0", ClampMax = "1.0"))
    float OceanSweepPosition = 0.5f;

    /** Every setting the last generation wrote (and every path it could not). */
    UPROPERTY(VisibleInstanceOnly, Transient, BlueprintReadOnly, Category = "Planet|Ocean|Seeding", meta = (TitleProperty = "Path"))
    TArray<FAtmosphereDrawRecord> OceanReport;

    // --- Terrain ---

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Terrain")
    UMaterialInterface* TerrainMaterial = nullptr;

    // --- Atmosphere (stage A1) ---

    /** The CloudAtmosphere atmosphere as a child (ASeededAtmosphereActor), generated from
     *  AtmosphereSeed. Off: parked and hidden (its march, sim bid and light off). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Atmosphere")
    bool bEnableAtmosphere = true;

    /** The atmosphere's model: the terrestrial slab (clouds and weather), or air alone. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Atmosphere", meta = (EditCondition = "bEnableAtmosphere"))
    EPlanetAtmosphereType AtmosphereType = EPlanetAtmosphereType::Terrestrial;

    /** The atmosphere's seed; -1: the terrain's (TerrestrialSettings.Seed), the route every
     *  component will share. A change regenerates the atmosphere (its sim restarts). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Atmosphere", meta = (EditCondition = "bEnableAtmosphere"))
    int32 AtmosphereSeed = -1;

    /** The archetypes and looks the seed draws from (the seeded actor's Set). Empty: the
     *  atmosphere's own (its class defaults). A change regenerates. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Atmosphere", meta = (EditCondition = "bEnableAtmosphere"))
    FAtmosphereGenerationSet AtmosphereSet;

    /** Stage A9: the terrain height (m above sea level) the weather sim reads as its highest
     *  (the surface map's elevation 1; higher ground counts as this). The sim's mountains hold
     *  back and steer the wind and lift it into cloud and rain (the sim config's Planet|Surface
     *  sets how much). The terrestrial generator's bake; 0: no terrain in the sim (all sea). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Atmosphere", meta = (EditCondition = "bEnableAtmosphere", ClampMin = "0.0", UIMax = "12000.0"))
    float AtmosphereTerrainHeight = 6000.0f;

    /** The land's surface water in the weather sim's moisture (its surface map's land share; the
     *  sim's land evaporates less than water): a kept lake counts as water, and a river's cells
     *  as this share of water, from none at the bake's RiverMinArea to all of it at 50 times that
     *  drainage. 0: only the sea. The terrain material's riparian green along rivers doesn't
     *  depend on it (VoxelLandClimate.ush). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Atmosphere", meta = (EditCondition = "bEnableAtmosphere", ClampMin = "0.0", ClampMax = "1.0"))
    float AtmosphereRiverWater = 0.5f;

    // --- Climate (stage A11: GetClimateAt) ---

    /** The mean temperature at the equator and at the poles at sea level (degrees C), between
     *  them as |sin(latitude)|^ClimateLatitudeExponent (Earth's annual means: about 27 and -25). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Climate")
    float ClimateEquatorTemperature = 27.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Climate")
    float ClimatePoleTemperature = -25.0f;

    /** Stage T5a: the latitude profile's exponent. 4 follows Earth's zonal annual means (about
     *  14 C at 45 degrees, -2 at 60, -18 at 75, with 27 and -25); 2 is stage A11's sin^2 (1 C at
     *  45 degrees: too cold at mid-latitudes). Lower: a colder planet away from the equator. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Climate", meta = (ClampMin = "0.5", UIMax = "8.0"))
    float ClimateLatitudeExponent = 4.0f;

    /** How fast the temperature falls with the ground's height (degrees C per km). */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Climate", meta = (ClampMin = "0.0", UIMax = "12.0"))
    float ClimateLapseRate = 6.5f;

    /** Degrees C per unit of the sim's warmth (its columns' thickness against their latitude's
     *  mean, about -0.1 to 0.1): the weather's standing warm ridges and cold troughs. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Climate", meta = (ClampMin = "0.0", UIMax = "200.0"))
    float ClimateWarmthScale = 60.0f;

    /** Stage T5a: the land's climate (Design/LandClimate.md): a map from the atmosphere's sim (a
     *  provisional model until its means settle) that the terrain material's climate node
     *  (VoxelLandClimateMaterial.ush) shows as snow, glacier ice, desert and plant cover, with
     *  the pixel's own height and slope. Terrestrial planets. Applies in place. */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Climate")
    FVoxelLandClimateSettings LandClimate;

    /** Stage T5a: where the land's climate stands (provisional, refining from the sim, settled). */
    UPROPERTY(VisibleInstanceOnly, Transient, BlueprintReadOnly, Category = "Planet|Climate")
    FString LandClimateStatus;

    // --- Gravity ---

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planet|Gravity")
    bool bEnableGravity = true;

    // --- Accessors ---

    UFUNCTION(BlueprintCallable, Category = "Planet")
    APlanetTerrainActor* GetTerrainActor() const { return TerrainActor; }

    UFUNCTION(BlueprintCallable, Category = "Planet")
    AOceanSphereActor* GetOceanActor() const { return OceanActor; }

    UFUNCTION(BlueprintCallable, Category = "Planet")
    APlanetGravityZone* GetGravityZone() const { return GravityZone; }

    UFUNCTION(BlueprintCallable, Category = "Planet")
    ASeededAtmosphereActor* GetAtmosphereActor() const { return AtmosphereActor; }

    /** Stage A12: the seed the ocean draws from (OceanSeed, or the terrain's for -1). */
    UFUNCTION(BlueprintPure, Category = "Planet|Ocean|Seeding")
    int32 GetOceanSeed() const;

    /** Stage A12: the settings the ocean gets: OceanSettings with OceanProfile's draws for the
     *  ocean's seed (OceanReport refilled). */
    FVoxelOceanSettings GenerateOceanSettings();

    /** The seed the atmosphere generates from (AtmosphereSeed, or the terrain's for -1). */
    UFUNCTION(BlueprintPure, Category = "Planet|Atmosphere")
    int32 GetAtmosphereSeed() const;

    /** 1 when the planet's surface is ready to build: always for the noise surface; for the
     *  terrestrial generator once the bake for the current settings is made or loaded. */
    UFUNCTION(BlueprintCallable, Category = "Planet")
    float GetBakeProgress() const;

    /** The terrestrial bake the planet is built with (null for the noise surface): T5e, with the
     *  ice shelf when it has one. */
    TSharedPtr<const FVoxelLandBake, ESPMode::ThreadSafe> GetLandBake() const { return TerrainBake(); }

    /** Rebuilds the compositor and every child on the next Tick (a child's structural
     *  setting changed, e.g. the terrain's TargetPrecision). */
    void RequestRebuild() { bPendingInitialize = true; }

    /** IVoxelTerrainOwner: the terrain's lattice changed (its TargetPrecision): the density, the
     *  edit store and the terrain are rebuilt together. */
    virtual void RequestTerrainRebuild() override { RequestRebuild(); }

    /** The water at a world point (Design/RiversLakes.md 3.6, R2): the sea, a kept lake or a
     *  river's channel over the ground along the planet's radius through the point, its
     *  surface, the ground, the depth, how deep the point lies under the surface, and a river's
     *  current. From the same shared code as the carving (VoxelLandCarve.ush), so it agrees with
     *  the terrain to the centimetre; edits are not taken into account (the water stays where
     *  it was: a dug hole fills only if it's below). Game thread (it reads the planet's
     *  compositor, which a rebuild replaces, and its transform); None before the planet is
     *  built. A node with execution pins: each call runs the land chain at the point (tens of
     *  microseconds), so read its fields from one call. */
    UFUNCTION(BlueprintCallable, BlueprintPure = false, Category = "Planet|Water")
    FVoxelWaterSample GetWaterAt(const FVector& WorldLocation) const;

    /** New ocean settings at run time: stored on the planet and forwarded to its ocean, which
     *  applies only what changed. */
    UFUNCTION(BlueprintCallable, Category = "Planet|Ocean")
    void SetOceanSettings(const FVoxelOceanSettings& InSettings);

    /** Stage W6g: the ocean's realistic look (FVoxelOceanSettings::ApplyRealisticPreset: physical
     *  wave heights, Monahan's whitecap coverage, the physical water light); only those settings
     *  change. */
    UFUNCTION(CallInEditor, BlueprintCallable, Category = "Planet|Ocean")
    void OceanPresetRealistic();

    /** Stage W6g: GodotOceanWaves' exaggerated look, the defaults (ApplyGodotPreset). */
    UFUNCTION(CallInEditor, BlueprintCallable, Category = "Planet|Ocean")
    void OceanPresetGodot();

    /** Stage A11: the climate at a world location (its direction from the planet's centre): the
     *  atmosphere's sim's long-run means there (GetClimateMap), the latitude's temperature, the
     *  ground's height (the land bake's). Stage T5a: with the land's climate, its values on flat
     *  ground at the bake's height there (GetSurfaceClimateAt has the point's own). Game thread. */
    UFUNCTION(BlueprintCallable, Category = "Planet|Climate")
    FVoxelPlanetClimate GetClimateAt(const FVector& WorldLocation) const;

    /** Stage T5a: the climate at a point on the surface with its normal (world), as the terrain
     *  material computes it there (the point's own height, slope, facing and breakup): snow
     *  underfoot, sand, plants. Game thread. */
    UFUNCTION(BlueprintCallable, Category = "Planet|Climate")
    FVoxelPlanetClimate GetSurfaceClimateAt(const FVector& WorldLocation, const FVector& SurfaceNormal) const;

    /** Stage T5b: captures the climate again: the atmosphere's sim restarts, spins up and gives a
     *  new snapshot (the climate shown stays until it lands). For authoring; a seed change does it
     *  by itself. */
    UFUNCTION(CallInEditor, BlueprintCallable, Category = "Planet|Climate")
    void RecaptureClimate();

    /** Stage A11: the atmosphere's latest climate map (null until its sim has given one; the
     *  last one stays while another planet drives the sim). */
    TSharedPtr<const struct FAtmosphereClimateMap, ESPMode::ThreadSafe> GetClimateMap() const;

    /** Stage A11: logs the climate over the planet (land and sea apart): the temperature, the
     *  precipitation, the humidity and the cloud, their means and ranges, from a grid of points. */
    UFUNCTION(CallInEditor, Category = "Planet|Climate")
    void LogClimate();

    // --- Lifecycle ---

    virtual void OnConstruction(const FTransform& Transform) override;
    virtual void BeginPlay() override;
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
    virtual void Destroyed() override;
    virtual void BeginDestroy() override;
    virtual bool ShouldTickIfViewportsOnly() const override { return true; }
    virtual void Tick(float DeltaTime) override;

    // IPooledActor as a proxy-CARRIED body -- driven only by the wrapping proxy,
    // never registered with the pool manager (so the arg-less OnAcquired() is unused).
    using IPooledActor::OnAcquired;   // un-hide the arg-less overload we don't implement
    virtual void OnAcquired(double WorldRadius) override;
    virtual void OnReturnToPool() override;

    // IStarLit -- the star system pushes its star's world position each frame. Stage A1: the
    // atmosphere aims its light and its march at it (OrientToStar).
    virtual void SetStarWorldPosition(const FVector& StarWorldPos) override;

    /** Last star position pushed through IStarLit (world space), and whether one arrived. */
    FVector GetStarWorldPosition() const { return StarWorldPosition; }
    bool HasStarWorldPosition() const { return bHasStarWorldPosition; }

    /** Master dormancy toggle: hides + tick-disables this actor and its child actors
     *  (terrain/ocean/gravity) and drops collision. A dormant planet does NO per-frame
     *  CPU or GPU work; the ocean keeps its pages, so waking is instant. Waking respects the
     *  bEnableOcean/Gravity feature flags. */
    void SetDormant(bool bDormant);

#if WITH_EDITOR
    virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
    virtual void PostEditMove(bool bFinished) override;
#endif

private:
    // The child actors. Not exported with a copy or a duplicate of the planet (the copy
    // spawns its own; SpawnChildActors also drops a child another planet owns).

    /** Terrain child actor (APlanetTerrainActor). Scale = PlanetRadius. */
    UPROPERTY(TextExportTransient)
    APlanetTerrainActor* TerrainActor = nullptr;

    /** Ocean child actor (AOceanSphereActor). Scale = OceanRadius. */
    UPROPERTY(TextExportTransient)
    AOceanSphereActor* OceanActor = nullptr;

    /** Gravity zone child actor (APlanetGravityZone). Centered on planet. */
    UPROPERTY(TextExportTransient)
    APlanetGravityZone* GravityZone = nullptr;

    /** Stage A1: the atmosphere child actor (ASeededAtmosphereActor). Scale = the visible
     *  surface's radius (the larger of the ocean's and the planet's). */
    UPROPERTY(TextExportTransient)
    ASeededAtmosphereActor* AtmosphereActor = nullptr;

    /** Shared compositor (surface density + edit store) passed to both terrain and
     *  ocean actors so they sample identical density. Built during Initialize. */
    TSharedPtr<FDensitySampleCompositor> SharedCompositor;

    // --- Change Detection ---
    // Cached values from last init/update, compared in OnConstruction to determine
    // whether a full rebuild or partial ocean update is needed.
    FVector LastInitScale = FVector::ZeroVector;
    double LastSeaLevel = -1.0;
    double LastNoiseAmplitudeRatio = -1.0;
    uint32 LastSurfaceSettingsHash = 0;
    EVoxelSurfaceGenerator LastGenerator = EVoxelSurfaceGenerator::Noise;
    uint32 LastTerrestrialHash = 0;
    bool bLastEnableOcean = true;
    bool bLastEnableGravity = true;
    bool bLastEnableAtmosphere = true;
    /** The seed and model the atmosphere last generated from (INDEX_NONE: not yet configured,
     *  its own first tick generates). */
    int32 LastAtmosphereSeed = INDEX_NONE;
    EPlanetAtmosphereType LastAtmosphereType = EPlanetAtmosphereType::Terrestrial;
    /** Stage A9: the bake and terrain height the atmosphere's surface map was made from (0: none). */
    uint32 LastSurfaceMapKey = 0;

    // --- Stage T5a: the land's climate (TickLandClimate) ---

    /** The land's share and the distance to the sea on the climate map's grid, for the bake
     *  ClimateBaseKey names (0: none). */
    TArray<float> ClimateLand;
    TArray<float> ClimateCoast;
    TArray<float> ClimateHeight;   // T5d2: the land's mean height a cell (m), for the sim's warmth
    uint32 ClimateBaseKey = 0;
    /** The sim's climate snapshot the land is built from (null: the provisional model). */
    TSharedPtr<const struct FAtmosphereClimateMap, ESPMode::ThreadSafe> ClimateSim;
    /** Stage T5b: the capture: what it is for (the bake, the atmosphere, the source), where it
     *  stands, and when it began (a snapshot requested before is an earlier sim's). */
    uint32 ClimateCaptureKey = 0;
    EVoxelPlanetClimateCapture ClimateCaptureState = EVoxelPlanetClimateCapture::None;
    double ClimateCaptureStart = 0.0;
    /** The wait's clocks: when the sim last stepped (and its step count then), and since when
     *  another planet has driven it (0: not). */
    double ClimateProgressTime = 0.0;
    int64 ClimateProgressSteps = -1;
    double ClimateOtherOwnerSince = 0.0;
    /** The map shown (the texture's), and while a new one fades in, the old one and the new. */
    FVoxelLandClimateMap ClimateShown;
    TArray<FVector4f> ClimateFrom;
    FVoxelLandClimateMap ClimateTarget;
    float ClimateFade = 1.0f;
    double ClimateUploadTime = 0.0;
    bool bClimateFromSim = false;
    /** The settings the shown map was made with (LandClimateMapHash). */
    uint32 ClimateMapHash = 0;
    /** Stage T5c: the land chain's climate (the target map and the sand's drift: the dunes are
     *  placed by it), and the hash of the one the terrain was built with (0: none). A new capture
     *  or new map settings after the build rebuild the terrain once (the shown map's fade doesn't:
     *  the field is the target's). */
    TSharedPtr<const FVoxelLandClimateField, ESPMode::ThreadSafe> LandClimateField;
    uint32 LandClimateFieldBuilt = 0;
    /** T5e: the climate base (ClimateBaseKey) LandClimateField was made on: the ice shelf is placed
     *  only by a field made for the current bake. */
    uint32 LandClimateFieldBaseKey = 0;
    /** The climate base's key for the current bake (EnsureLandClimateBase's; 0 without a bake). */
    uint32 CurrentClimateBaseKey() const;
    /** The parameters last given to the terrain (SetLandClimate). */
    FLinearColor ClimateParamsSent = FLinearColor(-1.0f, 0.0f, 0.0f, 0.0f);
    FLinearColor ClimateShapeSent = FLinearColor(-1.0f, 0.0f, 0.0f, 0.0f);
    FLinearColor ClimateTintSent = FLinearColor(-1.0f, 0.0f, 0.0f, 0.0f);
    TWeakObjectPtr<UTexture2DDynamic> ClimateTextureSent;
    TWeakObjectPtr<APlanetTerrainActor> ClimateTerrainSent;

    UPROPERTY(Transient)
    TObjectPtr<UTexture2DDynamic> LandClimateTexture;

    /** Every tick once built: the capture (a change after the build), the fade, the texture and
     *  the terrain's parameters. */
    void TickLandClimate(float DeltaTime);
    /** Stage T5b: the climate capture for the current bake and atmosphere: begins it (the
     *  atmosphere configured and its sim restarted), takes the snapshot when it lands, or the
     *  provisional model when none can come. True once captured (the build may go on). */
    bool UpdateClimateCapture();
    /** The land's share and the distance to the sea for the bake (false without one). */
    bool EnsureLandClimateBase();
    /** The map for the capture, faded in over the shown one. */
    void RebuildLandClimateTarget();
    void UploadLandClimate();
    /** What the map depends on (the settings' map hash and the planet's latitude curve and warmth). */
    uint32 LandClimateMapHash() const;
    /** Stage T5c, T5d: the climate the terrain's dunes and glacial layer are placed by (null: none:
     *  the climate off, not captured yet, or the pack has neither set), and its hash (0 for none). */
    TSharedPtr<const FVoxelLandClimateField, ESPMode::ThreadSafe> DuneClimate() const;
    /** Stage T5d2: whether the land chain's climate was made for other settings (the lapse rate,
     *  the ice sheets on or off). */
    bool IsLandClimateFieldStale() const;
    uint32 DuneClimateHash() const;
    /** What the surface map's land water comes from (AtmosphereRiverWater, RiverMinArea), for the
     *  surface map's and the climate capture's keys. */
    uint32 AtmosphereSurfaceWaterHash() const;
    /** The land climate's point (VoxelLandClimate::PointAt) at a planet-frame point (m). */
    FVoxelLandClimatePointResult LandClimatePointAt(const FVector& LocalM, const FVector& NormalLocal) const;
    /** The A11 climate filled in, and the land climate's at LocalM with NormalLocal if it's there. */
    FVoxelPlanetClimate ClimateAtLocal(const FVector& Dir, const FVector* SurfaceLocalM, const FVector& NormalLocal) const;

    bool bInitialized = false;

    /** A slider is still moving (editor): construction doesn't flag rebuilds until release. */
    bool bInteractiveEdit = false;

    FVector StarWorldPosition = FVector::ZeroVector;
    bool bHasStarWorldPosition = false;

    /** When true, Initialize runs on the next Tick. Set by OnConstruction for deferred
     *  child actor spawning (unsafe during construction). */
    bool bPendingInitialize = true;

    /** When true, ocean/gravity toggles and sea level changes are applied on the
     *  next Tick without a full terrain rebuild. */
    bool bPendingOceanUpdate = false;

    /** The terrestrial bake being made for the current settings (null when none is needed). */
    TSharedPtr<FVoxelLandBaker> LandBaker;

    /** The terrestrial bake the planet is built with: kept while a new one is made, so the
     *  planet shows the old surface until then. */
    TSharedPtr<const FVoxelLandBake, ESPMode::ThreadSafe> LandBake;

    /** Stage T5e: the bake the terrain is built with when the planet has an ice shelf (LandBake
     *  with the shelf raised by the captured climate: VoxelLandClimate::MakeIceShelfBake), and
     *  what it was made from. The climate and the atmosphere keep reading LandBake (the snapshot's
     *  own ground). */
    TSharedPtr<const FVoxelLandBake, ESPMode::ThreadSafe> ShelfBake;
    uint32 ShelfBakeHash = 0;
    /** Whether the planet asks for an ice shelf (a height, the land climate). */
    bool IceShelfOn() const;
    /** Makes ShelfBake for the current bake, climate and settings (or drops it). */
    void UpdateIceShelf();
    /** The terrain's bake: ShelfBake, else LandBake. */
    TSharedPtr<const FVoxelLandBake, ESPMode::ThreadSafe> TerrainBake() const { return ShelfBake.IsValid() ? ShelfBake : LandBake; }

    /** The noise pack (the peaks', detail, hills' and strata's sets) for the current settings, once ready
     *  (TickLandBake): held so it is there when the density takes it (VoxelLand::TryGetLandNoise). */
    TSharedPtr<const FVoxelLandNoiseSet, ESPMode::ThreadSafe> LandNoise;

    /** Terrestrial: advances the bake for the current settings and radius; true once LandBake
     *  is it. */
    bool TickLandBake();

    /** The density's shape for the current generator: the radius the heights are above, their
     *  range, and the sea radius. Terrestrial needs LandBake. */
    void ComputeShape(double& OutPlanetRadius, double& OutNoiseAmplitude, double& OutOceanRadius) const;

    /** NoiseAmplitude / PlanetRadius for the children (NoiseAmplitudeRatio itself for the noise
     *  surface, so its lattice is unchanged). */
    double ChildNoiseAmplitudeRatio(double PlanetRadius, double NoiseAmplitude) const;

    /** Full planet initialization: spawns child actors, builds the shared compositor,
     *  configures and initializes terrain/ocean/gravity. */
    void Initialize();

    /** The ocean from the planet's settings: radius, density, material and OceanSettings,
     *  shown and ticking, or hidden and stopped when bEnableOcean is off. Used by the first
     *  initialization and by every later update alike. */
    void ConfigureOcean(double PlanetRadius, double NoiseAmplitude, double OceanRadius);

    /** The gravity zone at the visible surface (the larger of the ocean and planet radii),
     *  or hidden and without collision when bEnableGravity is off. */
    void ConfigureGravity(double PlanetRadius, double OceanRadius);

    /** Stage A1: the atmosphere at the visible surface, from the seed, model and set, aimed at
     *  the star, and the ocean's sun; or parked and hidden when bEnableAtmosphere is off.
     *  bRegenerate: the seed's draws again even if the seed and model are unchanged (a set edit). */
    void ConfigureAtmosphere(double PlanetRadius, double OceanRadius, bool bRegenerate = false);
    /** Stage A9: the atmosphere's surface map from the land bake (elevation and land on the
     *  weather sim's grid layout), when the bake or the terrain height changed. */
    void ConfigureAtmosphereSurface();

    /** Whether the planet's set names anything (else the atmosphere keeps its own). */
    bool HasAtmosphereSet() const;
    /** Records the values FlagPendingWork compares against. */
    void RecordAppliedState();

    /** Compares the shape, sea level and toggles against what was applied and flags the
     *  rebuild or the ocean update for the next Tick. From OnConstruction, and from
     *  PostEditChangeProperty (a PIE world doesn't rerun construction after an edit). */
    void FlagPendingWork();

    /** Forwards the materials and OceanSettings to the children again; each applies only what
     *  changed (after an undo, which reports no property). */
    void ForwardChildSettings();

    /** Spawns terrain, ocean, and gravity child actors if not already present.
     *  Attaches them to PlanetRoot with absolute scale. Loads default materials. */
    void SpawnChildActors();

    /** Destroys all child actors and nulls the pointers. */
    void DestroyChildActors();

    /** Destroys the terrain children of the engine's base class this planet owns (saved before
     *  stage S1b; the TerrainActor property no longer takes them), attached or not. */
    void DestroyLegacyTerrainActors();

    /** Builds the shared compositor (VoxelDensity::MakeCompositor) with a fresh
     *  FSparseEditStore covering the terrain lattice's root box down to MaxDepth. */
    TSharedPtr<FDensitySampleCompositor> BuildCompositor(double PlanetRadius, double NoiseAmplitude, double RootExtent, int32 MaxDepth);

    /** Computes ocean radius from planet radius, noise amplitude, and SeaLevel.
     *  OceanRadius = PlanetRadius + SeaLevel * NoiseAmplitude, at least 1 cm (a sea level
     *  below the planet's centre gives a vanishing ocean, not a negative scale). */
    double ComputeOceanRadius(double PlanetRadius, double NoiseAmplitude) const;
};
